package com.example.SpringPrueba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPruebaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPruebaApplication.class, args);
	}

}
