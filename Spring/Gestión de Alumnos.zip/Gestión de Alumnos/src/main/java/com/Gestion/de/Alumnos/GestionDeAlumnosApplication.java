package com.Gestion.de.Alumnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDeAlumnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionDeAlumnosApplication.class, args);
	}

}
