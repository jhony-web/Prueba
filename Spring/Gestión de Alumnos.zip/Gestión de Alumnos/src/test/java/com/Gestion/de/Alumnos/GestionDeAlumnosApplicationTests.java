package com.Gestion.de.Alumnos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeAlumnosApplicationTests {

	@Test
	void contextLoads() {
	}

}
