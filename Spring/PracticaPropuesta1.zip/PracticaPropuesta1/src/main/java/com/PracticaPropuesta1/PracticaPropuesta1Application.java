package com.PracticaPropuesta1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaPropuesta1Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticaPropuesta1Application.class, args);
	}

}
